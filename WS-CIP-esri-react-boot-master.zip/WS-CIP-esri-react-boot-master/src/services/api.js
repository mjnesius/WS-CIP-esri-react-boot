// Copyright 2019 Esri
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//     http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.​

/**
 * Some general functions to help with requests
 */

import { makeRequest } from "./request";

export function getAppConfig() {
  return new Promise((resolve, reject) => {
    makeRequest({
      url: `http://tipdbt2/WaterSewerProjects/static/config.json`,
      method: "get"
    }).then(resp => resolve(resp));
  });
}

export function logout(portalUrl) {
  return new Promise((resolve, reject) => {
    makeRequest({
      url: `${portalUrl}/sharing/rest/oauth2/signout`,
      handleAs: "text"
    }).then(resp => resolve(resp), error => reject(error));
  });
}

export function getFeatures(FeatureUrl) {
  return new Promise((resolve, reject) => {
    makeRequest({
      url: `${FeatureUrl}/0/query?`,
      handleAs: "text"
    }).then(resp => resolve(resp), error => reject(error));
  });
}

export function setFilter(FeatureUrl) {
  return new Promise((resolve, reject) => {
    makeRequest({
      url: `${FeatureUrl}/0/query?`,
      handleAs: "text"
    }).then(resp => resolve(resp), error => reject(error));
  });
}
