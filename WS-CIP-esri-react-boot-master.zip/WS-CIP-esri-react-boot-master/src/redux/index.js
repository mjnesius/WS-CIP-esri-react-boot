export { default as auth } from './reducers/auth';
export { default as config } from './reducers/config';
export { default as map } from './reducers/map';
export { default as filter } from './reducers/filters';