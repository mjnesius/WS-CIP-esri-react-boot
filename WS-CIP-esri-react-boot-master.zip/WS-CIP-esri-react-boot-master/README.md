
#Built using Esri ArcGIS JS API + React + Redux
Detailed documentation can be found on the wiki: https://github.com/Esri/esri-react-boot/wiki

<a href="https://www.esri.com/en-us/home">
   <img src="http://psgd.esri.com/img/esri-react-boot/poweredByEsri.svg#1" width="150" height="auto"/>
</a>


